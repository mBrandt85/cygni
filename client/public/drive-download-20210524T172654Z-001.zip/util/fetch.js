const fetch = require('node-fetch')

module.exports = async (uri) => {
  const req = await fetch(uri)
  return await req.json()
}